#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "car.h"

using std::cerr;
using std::cout;
using std::endl;
using std::string;
using std::cin;


    int car::body()
    {
        cout << endl;
        cout << "-----CHOOSE A BODY TYPE----\n";
        cout << "CHOOSE 1 FOR SUV" << endl;
        cout << "CHOOSE 2 FOR SEDAN" << endl;
        cout << "CHOOSE 3 FOR HATCHBACK" << endl;
        cout << endl;
        cin >> x;
        if (x > 3)
        {
            cout << "INVALID OPTION\n";
            cout << endl;
            body();
        }
        else
        {
            cout << "YOU CHOOSE: " << x << "  as your choice\n";
        }
        return x;
    }
    int car::company()
    {
        cout << endl;
        cout << "----HERE IS A LIST OF CAR COMPANY NAME----\n";
        cout << "CHOOSE 1 FOR HYUNDAI\n";
        cout << "CHOOSE 2 FOR TATA\n";
        cout << "CHOOSE 3 FOR MARUTI_SUZUKI\n";
        cout << endl;
        cout << "CHOOSE A NUMBER FOR THE COMPANY  \n";
        cin >> y;
        if (y > 3)
        {
            cout << "INVALID OPTION\n";
            cout << endl;
            company();
        }
        else
        {
            cout << "YOU CHOOSE: " << y << "  as your company choice\n";
        }
        return y;
    }
	
    int car::fuel_type()
    {
        cout << "SELECT 1 FOR PETROL\n";
        cout << "SELECT 2 FOR DEISEL\n";
        cin >> z;
        if (z > 2)
        {
            cout << "INVALID OPTION\n";
            cout << endl;
            fuel_type();
        }
        else
            cout << "YOU choose: " << z << "  as your prefernce\n";
        return z;
    }


