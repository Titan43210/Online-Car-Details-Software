#ifndef __car
#define __car



    class car
    {
    private:
        long int price_petrol;
        long int price_deisel;
        long int Mileage;

    public:
        int x, y, z;
	int fuel_type();
        int body();
        int company();
    };



#endif
