#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "hatchback.h"
#include "car.h"


using std::cerr;
using std::cout;
using std::endl;
using std::string;
using std::cin;




    void hatchback::pet_hat(int y)
{
    if (y == 1)
    {
        cout << "-----List of hatchbacks of HYUNDAI in Petrol-----\n";
        cout << endl;
        cout << "1. I10\n";
        cout << "> Total variants are 10\n";
        cout << "> PRICE RANGE is Rs.5.24-7.88 Lakh\n";
        cout << "> MILEAGE :: 20-21 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
        cout << endl;
        cout << "2. I20\n";
        cout << "> Total varients are 6\n";
        cout << "> PRICE RANGE is Rs. 6.85-11.34 Lakh\n";
        cout << "> MILEAGE :: 12-17 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
    }
    else if (y == 2)
    {
        cout << "-----List of hatchbacks of TATA in Petrol-----\n";
        cout << endl;
        cout << "1. ALTROZ\n";
        cout << "> Total variants are 10\n";
        cout << "> PRICE RANGE is Rs.5.79-9.55 Lakh\n";
        cout << "> MILEAGE :: 19-20 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
        cout << endl;
        cout << "2. Tiago\n";
        cout << "> Total variants are 9\n";
        cout << "> PRICE RANGE is Rs.4.99-6.95 Lakh\n";
        cout << "> MILEAGE :: 22-23.84 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
    }
    else
    {
        cout << "-----List of hatchbacks of MARUTI SUZUKI in Petrol-----\n";
        cout << endl;
        cout << "1. BALENO\n";
        cout << "> Total variants are 10\n";
        cout << "> PRICE RANGE is ₹ 5.97-9.27 Lakh\n";
        cout << "> MILEAGE :: 19.56-21.96 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
        cout << endl;
        cout << "2. Celerio\n";
        cout << "> Total variants are 9\n";
        cout << "> PRICE RANGE is Rs. 4.65-5.90 Lakh\n";
        cout << "> MILEAGE :: 21.63 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
    }
}

void hatchback::des_hat(int y)
{
    if (y == 1)
    {
        cout << "-----List of hatchbacks of HYUNDAI in Diesel-----\n";
        cout << endl;
        cout << "1. I10\n";
        cout << "> Total variants are 6\n";
        cout << "> PRICE RANGE is Rs.6.24-8.88 Lakh\n";
        cout << "> MILEAGE :: 20-23 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
        cout << endl;
        cout << "2. I20\n";
        cout << "> Total varients are 7\n";
        cout << "> PRICE RANGE is Rs. 7.85-12.34 Lakh\n";
        cout << "> MILEAGE :: 12-18 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
    }
    else if (y == 2)
    {
        cout << "-----List of hatchbacks of TATA in Diesel-----\n";
        cout << endl;
        cout << "1. ALTROZ\n";
        cout << "> Total variants are 6\n";
        cout << "> PRICE RANGE is Rs.6.79-10.55 Lakh\n";
        cout << "> MILEAGE :: 19-20 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
        cout << endl;
        cout << "2. Tiago\n";
        cout << "> Total variants are 6\n";
        cout << "> PRICE RANGE is Rs.5.99-7.95 Lakh\n";
        cout << "> MILEAGE :: 23-24 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
    }
    else
    {
        cout << "-----List of hatchbacks of MARUTI SUZUKI in Diesel-----\n";
        cout << endl;
        cout << "1. BALENO\n";
        cout << "> Total variants are 0\n";
        cout << "> PRICE RANGE is ₹ 6.97-10.27 Lakh\n";
        cout << "> MILEAGE :: 22 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
        cout << endl;
        cout << "2. Celerio\n";
        cout << "> Total variants are 9\n";
        cout << "> PRICE RANGE is Rs. 5.65-6.90 Lakh\n";
        cout << "> MILEAGE :: 22 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
    }
}

