#ifndef __hatchback
#define __hatchback
#include "car.h"



   class hatchback : public car
{
public:
    void pet_hat(int y);
    void des_hat(int y);
};




#endif
