#include<iostream>
#include<string>
#include<chrono>
#include<thread>
#include "car.h"

#include "suv.h"
#include "sedan.h"
#include "hatchback.h"

using std::cin;
using std::cout;
using std::cerr;
using std::endl;
using std::string;
using std::this_thread::sleep_for;
using std::chrono::milliseconds;

int main()
{
	hatchback hb;
	sedan sed;
	SUV sv;
	car bt;
    cout << "-------Welcome to CAR World--------\n";
    int x = bt.body();
    int y = bt.company();
    int z = bt.fuel_type();
    if (z == 1)
    {
        if (x == 1)
            sv.pet(y);
        else if (x == 2)
            sed.pet_sed(y);

        else
            hb.pet_hat(y);
    }
    else
    {
        if (x == 1)
            sv.des(y);
        else if (x == 2)
            sed.des_sed(y);
        else
            hb.des_hat(y);
    }
    
}

