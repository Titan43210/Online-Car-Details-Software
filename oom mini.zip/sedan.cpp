#include <iostream>
#include <string>
#include <cstdlib>
#include <ctime>
#include "sedan.h"
#include "car.h"

using std::cerr;
using std::cout;
using std::endl;
using std::string;
using std::cin;
void sedan::pet_sed(int y)
{
    if (y == 1)
    {
        cout << "-----List of Sedans of HYUNDAI in Petrol-----\n";
        cout << endl;
        cout << "1. VERNA\n";
        cout << "> Total variants are 10\n";
        cout << "> PRICE RANGE is Rs. 9.19-15.25 Lakh*\n";
        cout << "> MILEAGE :: 17-25 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
        cout << endl;
        cout << "2. ELANTRA\n";
        cout << "> Total variants are 9\n";
        cout << "> PRICE RANGE is Rs. 17.85 - 21.12 Lakh*\n";
        cout << "> MILEAGE :: 11-16 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
    }
    else if (y == 2)
    {
        cout << "-----List of Sedans of TATA in Petrol-----\n";
        cout << endl;
        cout <<"Only 1 Option is available\n";
        cout << "TATA TIGOR\n";
        cout << "> Total variants are 6\n";
        cout << "> PRICE RANGE is Rs 5.60-7.74 Lakh*\n";
        cout << "> MILEAGE :: 20.3 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
    }
    else
    {
        cout << "-----List of Sedans of MARUTI SUZUKI in Petrol-----\n";
        cout << endl;
        cout << "1. CIAZ\n";
        cout << "> Total variants are 6\n";
        cout << "> PRICE RANGE is Rs.8.52 - 11.50 Lakh*\n";
        cout << "> MILEAGE :: 20.04 - 20.65 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
        cout << endl;
        cout << "2. DESIRE\n";
        cout << "> Total variants are 4\n";
        cout << "> PRICE RANGE is ₹ 5.97 Lakh -  9.02 Lakh*\n";
        cout << "> MILEAGE :: 24.12 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
    }
}

void sedan::des_sed(int y)
{
    if (y == 1)
    {
        cout << "-----List of Sedans of HYUNDAI in Diesel-----\n";
        cout << endl;
        cout << "1. VERNA\n";
        cout << "> Total variants are 12\n";
        cout << "> PRICE RANGE is Rs 10.19-16.25 Lakh*\n";
        cout << "> MILEAGE :: 17-26 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
        cout << endl;
        cout << "2. ELANTRA\n";
        cout << "> Total variants are 9\n";
        cout << "> PRICE RANGE is Rs. 18.85 - 22.12 Lakh*\n";
        cout << "> MILEAGE :: 11-17 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
    }
    else if (y == 2)
    {
        cout << "-----List of Sedans of TATA in Diesel-----\n";
        cout << endl;
        cout <<"Only 1 Option is available\n";
        cout << "TATA TIGOR\n";
        cout << "> Total variants are 6\n";
        cout << "> PRICE RANGE is Rs 6.60-8.74 Lakh*\n";
        cout << "> MILEAGE :: 21.3 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
    }
    else
    {
        cout << "-----List of Sedans of MARUTI SUZUKI in Diesel-----\n";
        cout << endl;
        cout << "1. CIAZ\n";
        cout << "> Total variants are 6\n";
        cout << "> PRICE RANGE is Rs. 9.52 - 12.50 Lakh*\n";
        cout << "> MILEAGE :: 20.04 - 21.65 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
        cout << endl;
        cout << "2. DESIRE\n";
        cout << "> Total variants are 4\n";
        cout << "> PRICE RANGE is ₹ 7.58 Lakh -  9.02 Lakh*\n";
        cout << "> MILEAGE :: 28.4 kmpl combined\n";
        cout << "> BOOKINGS AVAILABLE\n";
    }
}



