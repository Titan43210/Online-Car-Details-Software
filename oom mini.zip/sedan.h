#ifndef __sedan
#define __sedan
#include "car.h"



	class sedan : public car
{
public:
    void pet_sed(int y);
    void des_sed(int y);
};


#endif
