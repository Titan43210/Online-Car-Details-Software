#include<iostream>
#include<string>
#include<cstdlib>
#include<ctime>
#include "car.h"
#include "suv.h"



using std::string;
using std::cout;
using std::cerr;
using std::endl;
using std::cin;


    void SUV::pet(int y)
    {
        if (y == 1)
        {
            cout << "-----List of SUVs of HYUNDAI in petrol-----\n";
            cout << endl;
            cout << "1. CRETA\n";
            cout << "> Total variants are 11\n";
            cout << "> PRICE RANGE is Rs.9.99-17.70 Lakh*\n";
            cout << "> MILEAGE :: 17-21 kmpl combined\n";
            cout << "> BOOKINGS AVAILABLE \n ";
            cout << endl;
            cout << "2. VENUE\n";
            cout << "> Total variants are 7\n";
            cout << "> PRICE RANGE is Rs.6.92-11.78 Lakh*\n";
            cout << "> MILEAGE :: 17.52 kmpl combined\n";
            cout << "> BOOKINGS AVAILABLE \n ";
        }
        else if (y == 2)
        {
            cout << "-----List of SUVs of TATA in petrol-----\n";
            cout << endl;
            cout << "1. Harrier\n";
            cout << "> Total variants are 9\n";
            cout << "> PRICE RANGE is ₹14.3-20.82 Lakh\n";
            cout << "> MILEAGE :: 15-16 kmpl\n";
            cout << "> BOOKINGS AVAILABLE \n ";
            cout << endl;
             cout << "2. Nexon XZ\n";
            cout << "> Total variants are 18\n";
            cout << "> PRICE RANGE is ₹9.15-11.62 Lakh\n";
            cout << "> MILEAGE :: 17 kmpl\n";
            cout << "> BOOKINGS AVAILABLE \n ";
        }
        else
        {
            cout << "-----List of SUV's of MARUTI SUZUKI in petrol-----\n";
            cout << endl;
            cout << "1. Brezza\n";
            cout << "> Total variants are 9\n";
            cout << "> PRICE RANGE is Rs 7.45-11.21 Lakh\n";
            cout << "> MILEAGE :: 17.03-18.76 kmpl\n";
            cout << "> BOOKINGS AVAILABLE\n";
            cout << endl;
             cout << "2. Ertiga\n";
            cout << "> Total variants are 7\n";
            cout << "> PRICE RANGE is Rs 6.16-8.64 Lakh\n";
            cout << "> MILEAGE :: 17.99-19.01 kmpl\n";
            cout << "> BOOKINGS AVAILABLE\n";
        }
    }
    void SUV::des(int y)
    {
        if (y == 1)
        {
            cout << "-----List of SUV's of HYUNDAI in diesel-----\n";
            cout << "1. CRETA\n";
            cout << ">Total variants are 11\n";
            cout << ">PRICE RANGE is Rs.10.99-18.70 Lakh*\n";
            cout << ">MILEAGE :: 17-22 kmpl combined\n";
            cout << ">BOOKINGS AVAILABLE \n ";
            cout << endl;
            cout << "2. VENUE\n";
            cout << "> Total variants are 7\n";
            cout << "> PRICE RANGE is Rs.9.44-11.72 Lakh*\n";
            cout << "> MILEAGE :: 23.7 kmpl combined\n";
            cout << "> BOOKINGS AVAILABLE \n ";
        }
        else if (y == 2)
        {
            cout << "-----List of SUV's of TATa in diesel-----\n";
            cout << endl;
            cout << "1. Harrier\n";
            cout << "> Total variants are 9\n";
            cout << "> PRICE RANGE is ₹15.3-21.82 Lakh\n";
            cout << "> MILEAGE :: 15-17 kmpl\n";
            cout << "> BOOKINGS AVAILABLE \n ";
            cout << endl;
            cout << "2. Nexon XZ\n";
            cout << "> Total variants are 18\n";
            cout << "> PRICE RANGE is ₹9.48-12.95 Lakh\n";
            cout << "> MILEAGE :: 21.5 kmpl\n";
            cout << "> BOOKINGS AVAILABLE \n ";
        }
        else
        {
            cout << "-----List of SUV's of MARUTI SUZUKI in diesel-----\n";
            cout << endl;
            cout << "1. Brezza\n";
            cout << "> Total variants are 9\n";
            cout << "> PRICE RANGE is Rs 8.45-12.21 Lakh\n";
            cout << "> MILEAGE :: 17.03 to 19.76 kmpl\n";
            cout << "> BOOKINGS AVAILABLE\n";
            cout << endl;
            cout << "2. Ertiga\n";
            cout << "> Total variants are 7\n";
            cout << "> PRICE RANGE is Rs 8.57-10.44 Lakh\n";
            cout << "> MILEAGE :: 24.52 kmpl\n";
            cout << "> BOOKINGS AVAILABLE\n";
        }
    }



