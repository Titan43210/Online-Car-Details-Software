
#ifndef __SUV
#define __SUV



   class SUV : public car
    {
    public:
        void pet(int y);
        void des(int y);
    };



#endif
